﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using employee.records;

namespace FunPro.CW1._12928
{
    public partial class SwipeListForm : Form
    {
        public SwipeListForm()
        {
            InitializeComponent();
        }

        private void SwipeListForm_Load(object sender, EventArgs e)
        {
            MdiParent = MyForms.GetForm<ParentForm>();
        }

        private void LoadData()
        {
            dgv1.DataMember = "";
            dgv1.DataMember = null;
            dgv1.DataMember = new SwipeManager().GetAll();
        }
    }
}
