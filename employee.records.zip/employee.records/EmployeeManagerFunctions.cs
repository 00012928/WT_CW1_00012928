﻿using employer.records;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee.records
{
     public partial class EmployeeManager
    {
        public List<Employee> Sort(ByAttribute attribute)
        {
            switch (attribute)
            {
                case ByAttribute.Name:
                    var result = GetAll();
                    result.Sort(new ByNameComparor());
                    return result;
                case ByAttribute.StartDate:
                    var date = GetAll();
                    date.Sort(new ByStartDateComparor());
                    return date;
                case ByAttribute.DischargeDate:
                    var thing = GetAll();
                    thing.Sort(new ByDischargeDateComparor());
                    return thing;
            }

            //if we are here - something went wrong
            return null;
        }

        private class ByNameComparor : IComparer<Employee>
        {
            public int Compare(Employee x, Employee y)
            {
                return string.Compare(x.Name, y.Name);
            }
        }

        private class ByStartDateComparor : IComparer<Employee>
        {
            public int Compare(Employee x, Employee y)
            {
                return DateTime.Compare(x.StartDate, y.StartDate);
            }
        }

        private class ByDischargeDateComparor : IComparer<Employee>
        {
            public int Compare(Employee x, Employee y)
            {
                return DateTime.Compare(x.DischargeDate, y.DischargeDate);
            }
        }

    }
}
