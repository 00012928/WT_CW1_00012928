﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employer.records
{
    public class Employee
    {
        private string name;
        private DateTime dischargeDate;

        public int Id { get; set; }
        public string Name
        {
            get => name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Name can not be empty!");
                name = value;
            }
        }
        public bool IsActive { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime DischargeDate
        {
            get => dischargeDate; 
            set
            {
                if (value < StartDate)
                    throw new Exception("Discharge Date can not be earlier than Start Date!");
                dischargeDate = value;
            }
        }
    }
}
