﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace employer.records
{
    public class Swipe
    {
        private DateTime @out;

        public int Id { get; set; }
        public Employee EmpID { get; set; }
        public DateTime Date { get; set; }
        public DateTime In { get; set; }
        public DateTime Out
        {
            get => @out; set
            {
                if (value < In)
                    throw new Exception("Out can not be earlier than In!");
                @out = value;
            }
        }
    }
}
