﻿using employer.records;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employee.records
{
    public class SwipeManager : DbManager
    {
        public void Create(Swipe s)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
INSERT INTO sp_swipe
           (sp_emp_id_12928
           ,sp_date_12928
           ,sp_in_12928
           ,sp_out_12928)
     VALUES
           ('{s.EmpID}'
           ,{s.Date.Ticks}
           ,{s.In.Ticks}
           ,{s.Out.Ticks}";

                var command = new SQLiteCommand(sql, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                    connection.Close();
            }
        }

 
        public Swipe GetById(int id)
        {
            var connection = Connection;
            try
            {
                var sql = $@"
SELECT sp_id_12928
      ,sp_emp_id_12928
      ,sp_date_12928
      ,sp_in_12928
      ,sp_out_12928
FROM sp_swipe
WHERE sp_id_12928 = {id}";
                var command = new SQLiteCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var s = GetFromReader(reader);
                    return s;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            // if we are here - something went wrong
            return null;
        }

        public List<Swipe> GetAll()
        {
            var connection = Connection;
            var result = new List<Swipe>();
            try
            {
                var sql = @"
SELECT sp_id_12928
      ,sp_emp_id_12928
      ,sp_date_12928
      ,sp_in_12928
      ,sp_out_12928
FROM sp_swipe";
                var command = new SQLiteCommand(sql, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var s = GetFromReader(reader);
                    result.Add(s);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State != ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            return result;
        }

        private Swipe GetFromReader(SQLiteDataReader reader)
        {
            var s = new Swipe
            {
                Id = Convert.ToInt32(reader.GetValue(0)),
                EmpID = new EmployeeManager().GetById(Convert.ToInt32(reader.GetValue(1))),
                Date = new DateTime(Convert.ToInt64(reader.GetValue(2))),
                In = new DateTime(Convert.ToInt64(reader.GetValue(3))),
                Out = new DateTime(Convert.ToInt64(reader.GetValue(4))),
            };

            return s;
        }
    }
}
